# Image-Slider-JQuery
This particular project contains a slider that changes automatically and can also be done manually. 
The slider slides automatically unless you click any item or the next/previous button.You can manually navigate through each item using by either clicking the item or the next/previous button.
